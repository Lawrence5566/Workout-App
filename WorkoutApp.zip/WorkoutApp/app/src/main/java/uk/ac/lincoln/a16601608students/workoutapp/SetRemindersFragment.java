package uk.ac.lincoln.a16601608students.workoutapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.provider.CalendarContract;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.Manifest;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.Calendar;

public class SetRemindersFragment extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_reminders, container, false);

        /* stack overflow version?:
        Calendar cal = Calendar.getInstance();
        Intent intent = new Intent(Intent.ACTION_EDIT);
        intent.setType("vnd.android.cursor.item/event");
        intent.putExtra("beginTime", cal.getTimeInMillis());
        intent.putExtra("allDay", true);
        intent.putExtra("rrule", "FREQ=YEARLY");
        intent.putExtra("endTime", cal.getTimeInMillis()+60*60*1000);
        intent.putExtra("title", "A Test Event from android app");
        startActivity(intent);
        */

        //on opening this screen, check for permissions first and only run content if we have perms
        if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.WRITE_CALENDAR)
                != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted, so ask for them

            addCalenderPerms();
        }

        Button AddEventBtn = rootView.findViewById(R.id.AddEventBtn);
        AddEventBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                eventIntent(); //write simple event to calendar
            }
        });

        return rootView;
    }

    public void eventIntent() { //calender event intent
        Intent calendarIntent = new Intent(Intent.ACTION_INSERT, CalendarContract.Events.CONTENT_URI);
        Calendar beginTime = Calendar.getInstance();
        beginTime.set(2015, 12, 25, 00, 00);
        Calendar endTime = Calendar.getInstance();
        endTime.set(2015, 12, 25, 00, 01);
        calendarIntent.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, beginTime.getTimeInMillis());
        calendarIntent.putExtra(CalendarContract.EXTRA_EVENT_END_TIME, endTime.getTimeInMillis());
        calendarIntent.putExtra(CalendarContract.Events.TITLE, "Xmas!");
        calendarIntent.putExtra(CalendarContract.Events.EVENT_LOCATION, "North Pole");
        startActivity(calendarIntent);
    }

    //permissions stuff - ask only if we need to
    public void addCalenderPerms(){
        requestPermissions(
                new String[]{Manifest.permission.WRITE_CALENDAR},
                1);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) { //on result of calender perms ask
        switch (requestCode) {
            case 1: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the work!
                    // display short notification stating permission granted
                    Toast.makeText(this.getContext(), "Permission granted to access Calender!", Toast.LENGTH_SHORT).show();

                    //show the add reminders stuff
                    LinearLayout remindersLayout = getView().findViewById(R.id.remindersLayout);
                    remindersLayout.setVisibility(LinearLayout.VISIBLE);

                    //hide the perms stuff (if visible)
                    LinearLayout addPermsLayout = getView().findViewById(R.id.addPermsLayout);
                    addPermsLayout.setVisibility(LinearLayout.GONE);


                } else {
                    // permission denied, display stuff to let them try add again

                    LinearLayout remindersLayout = getView().findViewById(R.id.remindersLayout);
                    remindersLayout.setVisibility(LinearLayout.GONE); //hide stuff so they can't add reminders

                    LinearLayout addPermsLayout = getView().findViewById(R.id.addPermsLayout);
                    addPermsLayout.setVisibility(LinearLayout.VISIBLE); //show layout
                    if (addPermsLayout.getChildCount() < 1) { //if it has nothing
                        TextView tv1 = new TextView(this.getContext());
                        tv1.setText("Permission is not granted - we need this to access your calendar!");
                        Button btn1 = new Button(this.getContext());
                        btn1.setText("add Perms");
                        btn1.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                addCalenderPerms();
                            }
                        });

                        addPermsLayout.addView(tv1);
                        addPermsLayout.addView(btn1);
                    }

                }
                return;
            }
        }
    }

}
