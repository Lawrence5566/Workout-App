package uk.ac.lincoln.a16601608students.workoutapp;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

//using from https://stackoverflow.com/questions/10407159/how-to-manage-startactivityforresult-on-android/10407371#10407371

public class SelectExercise extends AppCompatActivity implements ReturnJson {
    int Id;             //id of TextView in table that this exercise selection was opened for
    private JSONArray ExerciseCategories;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selectexercise);

        Intent intent = getIntent();
        Id = intent.getIntExtra("ID", 1);

        //start async task
        parseJson("exercisecategory/");

        //start with GET /api/v2/exercisecategory/ getting api exercise categorys
    }

    public void parseJson(String extension){
        new ParseJson(this, extension).execute();
    }

    public void returnText(String text){ //send data back to table;
        Intent returnIntent = new Intent();
        returnIntent.putExtra("resultText", text);
        returnIntent.putExtra("resultID", Id);
        setResult(Activity.RESULT_OK, returnIntent);
        finish();
    }

    @Override
    public void ReturnJson(JSONArray result) { //set up list of categories
        ExerciseCategories = result; //store 'result' for later, (we can save this in memory in parseJson?)
        //need to store this so we can load from mem if we already have these categorys

        ListView listView = findViewById(R.id.apiListView);
        ArrayList<String> categories = new ArrayList<String>();
        ArrayList<Integer> Ids = new ArrayList<Integer>();

        try {
            // loop through json array "results"
            for (int i = 0; i < ExerciseCategories.length(); i++) {
                JSONObject json_obj = ExerciseCategories.getJSONObject(i);
                if (json_obj != null) {
                    //extract "name" and "id" of exercise category from object
                    categories.add(json_obj.getString("name"));
                    Ids.add(json_obj.getInt("id") );
                }
            }
        } catch (JSONException e) { //using getJSONObject so need catch
            e.printStackTrace();
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, categories);
        listView.setAdapter(adapter);//create list

        listView.setClickable(true);
        final Integer[] ids = Ids.toArray(new Integer[Ids.size()]);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> arg0, View view, int position, long id) {
                parseJson("exercise/?muscles=" + ids[position]);
            }
        });

    }

    @Override
    public void ReturnJsonExercises(JSONArray result){
        JSONArray Exercises = result; //need to store this so we can load from mem if we already have these items

        ListView listView = findViewById(R.id.apiListView);
        ArrayList<String> exercises = new ArrayList<String>();

        try {
            // loop through json array "results"
            for (int i = 0; i < Exercises.length(); i++) {
                JSONObject json_obj = Exercises.getJSONObject(i);
                if (json_obj != null) {
                    //extract "name" and "id" of exercise category from object
                    exercises.add(json_obj.getString("name"));
                }
            }
        } catch (JSONException e) { //using getJSONObject so need catch
            e.printStackTrace();
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, exercises);
        listView.setAdapter(adapter);//create list

        listView.setClickable(true);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> arg0, View view, int position, long id) {
                returnText(((TextView)view).getText().toString());
            }
        });
    }

}

