package uk.ac.lincoln.a16601608students.workoutapp;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

//using from https://stackoverflow.com/questions/10407159/how-to-manage-startactivityforresult-on-android/10407371#10407371

public class SelectExercise extends AppCompatActivity {
    int Id;             //id of TextView in table that this exercise selection was opened for
    String toReturnText;//Text to return to table, this will be the Exercise selected

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selectexercise);

        Intent intent = getIntent();
        Id = intent.getIntExtra("ID", 1);

        toReturnText = "just monika";
    }

    public void returnText(View v){ //send data back to table;
        Intent returnIntent = new Intent();
        returnIntent.putExtra("resultText", toReturnText);
        returnIntent.putExtra("resultID", Id);
        setResult(Activity.RESULT_OK, returnIntent);
        finish();
    }
}
