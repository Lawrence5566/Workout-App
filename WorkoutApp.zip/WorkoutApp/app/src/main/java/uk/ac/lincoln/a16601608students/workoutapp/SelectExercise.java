package uk.ac.lincoln.a16601608students.workoutapp;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

//using from https://stackoverflow.com/questions/10407159/how-to-manage-startactivityforresult-on-android/10407371#10407371

public class SelectExercise extends AppCompatActivity implements ReturnJson {
    int Id;             //id of TextView in table that this exercise selection was opened for

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selectexercise);

        Intent intent = getIntent();
        Id = intent.getIntExtra("ID", 1);

        //start async task
        new ParseJson(this).execute();


        //start with GET /api/v2/exercisecategory/ getting api exercise categorys
    }

    public void returnText(View v, String text){ //send data back to table;
        Intent returnIntent = new Intent();
        returnIntent.putExtra("resultText", text);
        returnIntent.putExtra("resultID", Id);
        setResult(Activity.RESULT_OK, returnIntent);
        finish();
    }

    @Override
    public void ReturnJson(JSONArray result) { //set up list of categories
        //create layout param for list items

        LinearLayout.LayoutParams textParam = new LinearLayout.LayoutParams
               (LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        LinearLayout categoryList = this.findViewById(R.id.CategoryLayout);
        try {
            // loop through json array "results"
            for (int i = 0; i < result.length(); i++) {
                JSONObject json_obj = result.getJSONObject(i);
                if (json_obj != null) {
                    //add name of object to list
                    TextView tv = new TextView(this);
                    final String name = json_obj.getString("name"); //extract "name" of exercise from object
                    tv.setText(name); //add "name" to textView
                    tv.setLayoutParams(textParam);
                    tv.setClickable(true);
                    tv.setTextSize(20);
                    tv.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {
                            returnText(v, name);
                        }
                    });

                    categoryList.addView(tv); //add to list of categories

                }
            }
        } catch (JSONException e) { //using getJSONObject so need catch
            e.printStackTrace();
        }

    }
}

