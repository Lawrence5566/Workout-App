package uk.ac.lincoln.a16601608students.workoutapp;

import android.app.Activity;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.ref.WeakReference;

//from lincoln uni workshop task 5 @derekfoster
//also uses https://stackoverflow.com/questions/12252654/android-how-to-update-an-ui-from-asynctask-if-asynctask-is-in-a-separate-class

public class ParseJson extends AsyncTask<String, String, String>{
    WeakReference<Activity> mWeakActivity;

    // set the url of the web service to call
    String yourServiceUrl = "https://wger.de/api/v2/";
    String categorys = "exercisecategory/";
    String currentExtension = categorys;
    JSONArray results;

    //pass in context as constructor from SelectExercise
    public ParseJson(Activity activity){
        mWeakActivity = new WeakReference<Activity>(activity);
    }

    @Override
    // this method is used to connect to rest service and download data, in this case, and can be used to setup task (like show loading bar)
    protected void onPreExecute() {}

    @Override
    // this method runs background thread immediately after onPreExecute
    protected String doInBackground(String... arg0)  {
        //note: do not use weakActivity in here

        try {
            // create new instance of the httpConnect class
            HttpConnect jParser = new HttpConnect();

            // get json string from service url
            String json = jParser.getJSONFromUrl(yourServiceUrl + currentExtension);

            // parse returned json string into json object
            JSONObject jsonObject = new JSONObject(json);

            results = jsonObject.getJSONArray("results");

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    // below method will run when service HTTP request is complete
    protected void onPostExecute(String strFromDoInBg) {
        //uses results from query above

        Activity activity = mWeakActivity.get();
        if (activity != null){
            LinearLayout categoryList = activity.findViewById(R.id.CategoryLayout);
            try {
            // loop through json array "results"
            for (int i = 0; i < results.length(); i++) {
                JSONObject json_obj = results.getJSONObject(i);
                    if (json_obj != null) {
                        //add name of object to list
                        TextView tv = new TextView(activity);
                        tv.setText(json_obj.getString("name")); //extract "name" from object to textview
                        categoryList.addView(tv); //add to list of categories
                    }
                }
            } catch (JSONException e) { //using getJSONObject so need catch
                e.printStackTrace();
            }
        }

        /*
        // // from https://stackoverflow.com/questions/4837834/2-lines-in-a-listview-item
        List<Map<String, String>> data = new ArrayList<Map<String, String>>();

        for (int i = 0; i < items.size(); i++){
            Map<String, String> datum = new HashMap<String, String>(2); //create hashmap for each row
            datum.put("First Line", items.get(i));
            datum.put("Second Line",items2.get(i));
            data.add(datum);
        }

        //use a simple adapter
        SimpleAdapter adapter = new SimpleAdapter(tweets.this, data, android.R.layout.simple_list_item_2,
                new String[] {"First Line", "Second Line" },
                new int[] {android.R.id.text1, android.R.id.text2 });
        // //

        ListView list = (ListView)findViewById(R.id.tweetList);
        list.setAdapter(adapter);
        list.setEmptyView(findViewById(R.id.empty));

        TextView profileNameTv = (TextView)findViewById(R.id.textView2);
        profileNameTv.setText(profileName);

        ImageView profileImg = (ImageView)findViewById(R.id.tweetpp);

        //download jpg or png, this will put it in 'bitmap' variable
        new GetImageFromURL(profileImg).execute(profileImgURL);

        profileImg.setImageBitmap(bitmap);*/

    }
}