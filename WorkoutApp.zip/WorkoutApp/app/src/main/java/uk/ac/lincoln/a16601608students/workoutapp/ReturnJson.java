package uk.ac.lincoln.a16601608students.workoutapp;

import org.json.JSONArray;

public interface ReturnJson {
    void ReturnJson(JSONArray result);
    void ReturnJsonExercises(JSONArray result);
}
