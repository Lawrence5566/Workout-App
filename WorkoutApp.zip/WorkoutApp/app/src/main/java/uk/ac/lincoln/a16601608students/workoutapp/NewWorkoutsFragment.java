package uk.ac.lincoln.a16601608students.workoutapp;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class NewWorkoutsFragment extends Fragment {
    private int DayNumber = 0;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //when fragment loaded, create a new temporary workout with 0 tables in - make this a class?

        //instantiate sqlLiteHelper to create db:
        SQLiteHelper mDbHelper = new SQLiteHelper(getContext());

        View rootView = inflater.inflate(R.layout.fragment_newworkout, container, false);

        //explicitly link method with button, as xml links don't work with fragments
        //from https://stackoverflow.com/questions/38942843/android-method-is-never-used-warning-for-onclick-method
        Button addDayButton = rootView.findViewById(R.id.addDayButton);
        addDayButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                addDay(v);
            }
        });

        Button addRow = rootView.findViewById(R.id.addTestRow); //add temp listener for testing
        addRow.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                addTestRow(v);
            }
        });

        Button testDisplay = rootView.findViewById(R.id.testDisplay); //add temp listener for testing
        testDisplay.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                testDisplay(v);
            }
        });

        return rootView;
    }

    public void testDisplay(View view) {
        displayTableToScreen("DayTable" + 1);
    }

    public void displayTableToScreen(String tableName){
        SQLiteHelper mDbHelper = new SQLiteHelper(getContext()); //get db to work with
        Cursor cursor = mDbHelper.displayTable(tableName); //return cursor for * table info

        // displaying titles: //

        //get tables layout
        LinearLayout dayTablesLayout = getView().findViewById(R.id.dayTableLayout);

        //set column layout for this table
        LinearLayout columnLayout = new LinearLayout(this.getContext());
        columnLayout.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT));
        columnLayout.setOrientation(LinearLayout.HORIZONTAL);

        dayTablesLayout.addView(columnLayout); //add column layout to tables list

        for (String colName : cursor.getColumnNames()){ //for each column in table, add headings
            TextView col = new TextView(getContext());
            col.setText(colName);
            columnLayout.addView(col);
        }

        //insert blank text view after for space between days
        TextView blank = new TextView(getContext());
        blank.setText("");
        dayTablesLayout.addView(blank);

        //displaying titles:
        /*LinearLayout columnLayout = getView().findViewById(R.id.columnLayout);
        TextView col1 = new TextView(getContext());
        TextView col2 = new TextView(getContext());
        TextView col3 = new TextView(getContext());
        TextView col4 = new TextView(getContext());

        columnLayout.addView(col1);
        columnLayout.addView(col2);
        columnLayout.addView(col3);
        columnLayout.addView(col4);
        */

        //displaying data:
        if (cursor.getCount() > 0){        //if data exists
            cursor.moveToFirst();   //move to first item
            do{ //foreach value in cursor
                String fullCol = cursor.getString(0) + " " + cursor.getString(1) + " " + cursor.getString(2) + " " + cursor.getString(3);
               // print test text of full coloumn
                Toast.makeText(this.getContext(), "length: " + cursor.getCount() + "    "+ fullCol, Toast.LENGTH_LONG).show();
            } while(cursor.moveToNext()); //need to put this after so Do runs first otherwise it skips first item
        }


    }

    //create test row
    public void addTestRow(View view){
        SQLiteHelper mDbHelper = new SQLiteHelper(getContext()); //get db to work with
        String tableName = "DayTable" + DayNumber;

        //add test row to current daytable
        long test = mDbHelper.insert(tableName, "test ex", 3, 4 );

        if (test == -1){ //error: could not insert row
            Toast.makeText(this.getContext(), "error: could not insert row", Toast.LENGTH_LONG).show();
        } else{
            Toast.makeText(this.getContext(), "Row inserted", Toast.LENGTH_LONG).show();
            //now display table after adding a row is successful
            displayTableToScreen(tableName);
        }

    }

    //creates a table in database
    public void addDay(View view){
        DayNumber += 1;
        String tableName = "DayTable" + DayNumber;
        Toast.makeText(this.getContext(), "add day", Toast.LENGTH_LONG).show();

        SQLiteHelper mDbHelper = new SQLiteHelper(getContext()); //get db to work with
        mDbHelper.insertTable(tableName);

        //now display table after adding a table is successful
        displayTableToScreen(tableName);
    }
}
