package uk.ac.lincoln.a16601608students.workoutapp;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class NewWorkoutsFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //when fragment loaded, create a new temporary workout with 0 tables in - make this a class?

        //instantiate sqlLiteHelper:
        SQLiteHelper mDbHelper = new SQLiteHelper(getContext());

        View rootView = inflater.inflate(R.layout.fragment_newworkout, container, false);

        //explicitly link method with button, as xml links don't work with fragments
        //from https://stackoverflow.com/questions/38942843/android-method-is-never-used-warning-for-onclick-method
        Button addDayButton = rootView.findViewById(R.id.addDayButton);
        addDayButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                addDay(v);
            }
        });

        Button addRow = rootView.findViewById(R.id.addTestRow); //add temp listener for testing
        addRow.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                addTestRow(v);
            }
        });

        return rootView;
    }

    //create test row
    public void addTestRow(View view){
        Toast.makeText(this.getContext(), "button add test row works", Toast.LENGTH_LONG).show();

    }

    //creates a table in database
    public void addDay(View view){
        Toast.makeText(this.getContext(), "button add day works", Toast.LENGTH_LONG).show();
    }
}
