package uk.ac.lincoln.a16601608students.workoutapp;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class NewWorkoutsFragment extends Fragment {
    LinearLayout dayTableLayout ;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //when fragment loaded, create a new temporary workout with 0 tables in - make this a class?

        View rootView = inflater.inflate(R.layout.fragment_newworkout, container, false);

        //explicitly link method with button, as xml links don't work with fragments
        //from https://stackoverflow.com/questions/38942843/android-method-is-never-used-warning-for-onclick-method
        Button addDayButton = rootView.findViewById(R.id.addDayButton);
        addDayButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                addDay(v);
            }
        });

        dayTableLayout = (LinearLayout)rootView.findViewById(R.id.dayTableLayout);

        return rootView;
    }

    //creates a table in current workout
    public void addDay(View view){
        //create new table
        TableLayout newTable = new TableLayout(this.getContext());

        //create xlm params
        TableLayout.LayoutParams layout = new TableLayout.LayoutParams(
                TableLayout.LayoutParams.MATCH_PARENT, TableLayout.LayoutParams.WRAP_CONTENT);
        layout.rightMargin = 2;
        newTable.setLayoutParams(layout);

        //create row that contains all the column headings
        TableRow row = new TableRow(this.getContext());
        row.setLayoutParams((new TableRow.LayoutParams(
                TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT)));

        //create headings
        TextView HeadingTV1 = new TextView(this.getContext());
        HeadingTV1.setText("Exercise");
        HeadingTV1.setLayoutParams(new TableRow.LayoutParams(
                TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));
        TextView HeadingTV2 = new TextView(this.getContext());
        HeadingTV2.setText("Reps");
        HeadingTV2.setLayoutParams(new TableRow.LayoutParams(
                TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));
        TextView HeadingTV3 = new TextView(this.getContext());
        HeadingTV3.setText("Sets");
        HeadingTV3.setLayoutParams(new TableRow.LayoutParams(
                TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));
        TextView HeadingTV4 = new TextView(this.getContext());
        HeadingTV4.setText("Muscles");
        HeadingTV4.setLayoutParams(new TableRow.LayoutParams(
                TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));

        row.addView(HeadingTV1);
        row.addView(HeadingTV2);
        row.addView(HeadingTV3);
        row.addView(HeadingTV4);
        newTable.addView(row);

        dayTableLayout.addView(newTable);

    }
}
