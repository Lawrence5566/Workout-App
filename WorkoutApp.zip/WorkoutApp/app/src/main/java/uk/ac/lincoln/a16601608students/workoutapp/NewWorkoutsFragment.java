package uk.ac.lincoln.a16601608students.workoutapp;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class NewWorkoutsFragment extends Fragment {
    private int DayNumber = 0;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //when fragment loaded, create a new temporary workout with 0 tables in - make this a class?

        //instantiate sqlLiteHelper to create db:
        SQLiteHelper mDbHelper = new SQLiteHelper(getContext());

        View rootView = inflater.inflate(R.layout.fragment_newworkout, container, false);

        //explicitly link method with button, as xml links don't work with fragments
        //from https://stackoverflow.com/questions/38942843/android-method-is-never-used-warning-for-onclick-method
        Button addDayButton = rootView.findViewById(R.id.addDayButton);
        addDayButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                addDay(v);
            }
        });

        Button addRow = rootView.findViewById(R.id.addRow); //add temp listener for testing
        addRow.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                addRow(v);
            }
        });

        Button testDisplay = rootView.findViewById(R.id.testDisplay); //add temp listener for testing
        testDisplay.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                testDisplay(v);
            }
        });

        return rootView;
    }

    public void testDisplay(View view) {
        displayTableToScreen("DayTable" + DayNumber);
    }

    public void displayTableToScreen(String tableName) {

        //each table and data row has Tag, if tag exists in the view, we dont create new views for it

        SQLiteHelper mDbHelper = new SQLiteHelper(getContext()); //get db to work with
        Cursor cursor = mDbHelper.displayTable(tableName); //return cursor for * table info

        LinearLayout dayTableLayout;
        //get current all tables layout
        LinearLayout allDayTablesLayout = getView().findViewById(R.id.dayTableLayout);

        //set layout for this new day table
        if (getView().findViewWithTag(tableName) == null){ //if no table found with tablename
            dayTableLayout = new LinearLayout(this.getContext());
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT );
            params.setMargins(0,1,0,10);
            dayTableLayout.setOrientation(LinearLayout.VERTICAL);
            dayTableLayout.setLayoutParams(params);
            dayTableLayout.setTag(tableName); //set tag to table name, to find it later

           //add to current all tables layout
            allDayTablesLayout.addView(dayTableLayout);

            // displaying titles: //

            //create a column layout for this row
            LinearLayout columnLayout = new LinearLayout(this.getContext());
            columnLayout.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT));
            columnLayout.setOrientation(LinearLayout.HORIZONTAL);

            dayTableLayout.addView(columnLayout); //add column layout to table

            for (String colName : cursor.getColumnNames()){ //for each column in table, add headings
                TextView col = new TextView(getContext());
                col.setText(colName);
                columnLayout.addView(col);
                col.setLayoutParams(new TableRow.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT , ViewGroup.LayoutParams.WRAP_CONTENT, 1));
                col.setGravity(Gravity.CENTER); //gravitate to center of cell
                col.setBackground(this.getContext().getDrawable(R.drawable.columntitlebox));  //add cell properties
            }

        } else{ //table already exists
            dayTableLayout = getView().findViewWithTag(tableName);
        }

        //displaying data (content):

        if (cursor.getCount() > 0){        //if data exists to be added
            cursor.moveToFirst();   //move to first item
            do{ //foreach value in cursor

                //if this datarow doesnt exist
                if (getView().findViewWithTag(tableName + "datarow" + cursor.getString(0)) == null){

                    //create a column layout for this row
                    LinearLayout newColumnLayoutRow = new LinearLayout(this.getContext());
                    newColumnLayoutRow.setLayoutParams(new LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.MATCH_PARENT));
                    newColumnLayoutRow.setOrientation(LinearLayout.HORIZONTAL);
                    newColumnLayoutRow.setTag(tableName + "datarow" + cursor.getString(0));

                    for (int i = 0; i < 4; i++){ //have to set individually to pass into customTextWatcher
                        if (i == 0 || i == 1){ //exercise id's, keep normal text views
                            TextView col = new TextView(getContext()); //final in temp for onclick
                            col.setTextSize(13); //otherwise text and editViews are different sizes
                            col.setText(cursor.getString(i));
                            newColumnLayoutRow.addView(col);
                            col.setLayoutParams(new TableRow.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT , ViewGroup.LayoutParams.WRAP_CONTENT, 1));
                            col.setGravity(Gravity.CENTER); //gravitate to center of cell
                            col.setBackground(this.getContext().getDrawable(R.drawable.columncontentbox));  //add cell properties
                            final int colID = View.generateViewId(); //generate ID for returning data to it from SelectExercise
                            col.setId(colID );
                            if (i == 1){ //exercise name
                                col.setClickable(true);
                                col.setOnClickListener(new View.OnClickListener(){
                                    @Override
                                    public void onClick(View v){
                                        getExercise(colID); //pass in ID to selectExercise
                                    }
                                });
                            }
                        }
                        else{ //third and fourth column, make typeable numbers (have to be ints)
                            EditText col = new EditText(getContext());
                            col.setInputType(InputType.TYPE_CLASS_NUMBER);
                            col.setTextSize(13); //otherwise text and editViews are different sizes
                            col.setText(cursor.getString(i));
                            newColumnLayoutRow.addView(col);
                            col.setLayoutParams(new TableRow.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT , ViewGroup.LayoutParams.WRAP_CONTENT, 1));
                            col.setGravity(Gravity.CENTER); //gravitate to center of cell
                            col.setBackground(this.getContext().getDrawable(R.drawable.columncontentbox));  //add cell properties
                            col.addTextChangedListener(new CustomTextWatcher(col, tableName, cursor.getColumnName(i), cursor.getString(0))); //use customTextWatcher
                        }

                    }

                    dayTableLayout.addView(newColumnLayoutRow); //add column layout to tables list
                }

            } while(cursor.moveToNext()); //need to put this after so Do runs first otherwise it skips first item
        }

    }

    //add row
    public void addRow(View view){
        SQLiteHelper mDbHelper = new SQLiteHelper(getContext()); //get db to work with
        String tableName = "DayTable" + DayNumber;

        //add test row to current daytable
        long test = mDbHelper.insert(tableName, "tap to enter ex", 5, 4 );

        if (test == -1){ //error: could not insert row
            Toast.makeText(this.getContext(), "error: could not insert row", Toast.LENGTH_LONG).show();
        } else{
            Toast.makeText(this.getContext(), "Row inserted", Toast.LENGTH_LONG).show();
            //now display table after adding a row is successful
            displayTableToScreen(tableName);
        }
    }

    //creates a table in database
    public void addDay(View view){
        DayNumber += 1;
        String tableName = "DayTable" + DayNumber;

        SQLiteHelper mDbHelper = new SQLiteHelper(getContext()); //get db to work with
        mDbHelper.insertTable(tableName);
        mDbHelper.insert(tableName, "tap to enter ex", 5, 4 ); //insert starting row

        //now display table after adding a table is successful
        displayTableToScreen(tableName);
    }

    public void getExercise(int id){
        int PICK_CONTACT_REQUEST = 1; //request code

        Intent intent = new Intent(this.getContext(), SelectExercise.class);
        intent.putExtra("ID", id);
        startActivityForResult(intent, PICK_CONTACT_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) { //on selectExercise result

        if (requestCode == 1) {
            if(resultCode == Activity.RESULT_OK){
                String result = data.getStringExtra("resultText");
                int ID = data.getIntExtra("resultID", 1);

                TextView col = getView().findViewById(ID);  //find the Exercise column they tapped
                col.setText(result);                        //set the exercise they chose

            }
            if (resultCode == Activity.RESULT_CANCELED) {
                //if there's no result
            }
        }
    }//onActivityResult

    private class CustomTextWatcher implements TextWatcher {
        private EditText mEditText;
        private String colName;
        private String tableName;
        private String ID;

        public CustomTextWatcher(EditText e, String tblName, String columnName, String id) {
            mEditText = e;
            colName = columnName;
            tableName = tblName;
            ID = id;
        }

        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        public void afterTextChanged(Editable s) {
            //update db
            SQLiteHelper mDbHelper = new SQLiteHelper(getContext());
            int n = mDbHelper.updateTable(tableName, colName, s.toString(), ID);
        }
    }
}

