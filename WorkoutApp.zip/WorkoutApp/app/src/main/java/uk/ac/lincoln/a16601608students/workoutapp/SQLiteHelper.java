package uk.ac.lincoln.a16601608students.workoutapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

//data>data>uk.ac.lincoln etc gets to local file storage

public class SQLiteHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "Workouts.db";
    private static final String TABLE_NAME = "Daytable";
    private static final String COLUMN_NAME_ONE = "exerciseNumb";;
    private static final String COLUMN_NAME_TWO = "exercise";
    private static final String COLUMN_NAME_THREE = "reps";
    private static final String COLUMN_NAME_FOUR = "sets";

    public static String SQL_CREATE_TABLE(String tableName){
        return "CREATE TABLE " + tableName + " (" +
                COLUMN_NAME_ONE + " INTEGER PRIMARY KEY," +
                COLUMN_NAME_TWO + " TEXT," +
                COLUMN_NAME_THREE + " INTEGER," +
                COLUMN_NAME_FOUR + " INTEGER)";
    }

    public static String SQL_DELETE_ENTRIES(String tableName){
        return "DROP TABLE IF EXISTS " + tableName;
    }

    public SQLiteHelper(Context context) { //creates database when constructor called
        super(context, DATABASE_NAME, null, 1); //create database
        SQLiteDatabase db = this.getWritableDatabase(); //get db
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_TABLE(TABLE_NAME));
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // This database is only a cache for online data, so its upgrade policy is
        // to simply to discard the data and start over
        db.execSQL(SQL_DELETE_ENTRIES(TABLE_NAME));
        onCreate(db);
    }
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }

}


