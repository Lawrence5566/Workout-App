package uk.ac.lincoln.a16601608students.workoutapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

//data>data>uk.ac.lincoln etc gets to local file storage
//Written using https://developer.android.com/training/data-storage/sqlite#java

public class SQLiteHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "Workouts.db";
    private static final String TABLE_NAME = "Daytable";
    private static final String COLUMN_NAME_ONE = "exerciseNumb";;
    private static final String COLUMN_NAME_TWO = "exercise";
    private static final String COLUMN_NAME_THREE = "reps";
    private static final String COLUMN_NAME_FOUR = "sets";

    public static String SQL_CREATE_TABLE(String tableName){
        return "CREATE TABLE " + tableName + " (" +
                COLUMN_NAME_ONE + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_NAME_TWO + " TEXT," +
                COLUMN_NAME_THREE + " INTEGER," +
                COLUMN_NAME_FOUR + " INTEGER)";
    }

    public static String SQL_DELETE_ENTRIES(String tableName){
        return "DROP TABLE IF EXISTS " + tableName;
    }

    public SQLiteHelper(Context context) { //creates database when constructor called
        super(context, DATABASE_NAME, null, 1); //create database
        SQLiteDatabase db = this.getWritableDatabase(); //get db
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //db.execSQL(SQL_CREATE_TABLE(TABLE_NAME)); //don't create a table oncreate, user needs to add one
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // This database is only a cache for online data, so its upgrade policy is
        // to simply to discard the data and start over
        db.execSQL(SQL_DELETE_ENTRIES(TABLE_NAME));
        onCreate(db);
    }
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }

    public void insertTable(String tableName){
        SQLiteDatabase db = this.getWritableDatabase(); //get db
        db.execSQL(SQL_CREATE_TABLE(tableName));
    }

    public long insert(String tableName, String exercise, int reps, int sets ) {
        // Gets the data repository in write mode
        SQLiteDatabase db = this.getWritableDatabase(); //get db

        // Create a new map of values, where column names are the keys
        ContentValues values = new ContentValues();
        //values.put(COLUMN_NAME_ONE, number); //autoincrements, therefore don't need value here
        values.put(COLUMN_NAME_TWO, exercise);
        values.put(COLUMN_NAME_THREE, reps);
        values.put(COLUMN_NAME_FOUR, sets);

        // Insert the new row, returning the primary key value of the new row
        //null = do not insert a row if there are no values
        long newRowId = db.insert(tableName, null, values);
        //will return -1 if there was an error inserting value

        return newRowId;

    }

}


