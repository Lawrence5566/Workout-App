package uk.ac.lincoln.a16601608students.workoutapp;

import android.content.pm.PackageManager;
import android.support.v4.app.FragmentManager;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout drawer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SQLiteHelper mDbHelper = new SQLiteHelper(this);
        mDbHelper.createWorkoutsTable(); //create workouts table for later

        //set toolbar as action bar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawer = findViewById(R.id.drawer_layout);
        //ref & add navigation view to listen to click events on the drawer menu
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this); //can pass main acitivty as it implements navItemSelected

        //handle opening drawer toggle, including adding "three lines" icon to toolbar
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        //set starting fragment
        //but if runtime config changed (like rotating device), onCreate will run again
        //therefore only load start fragment if savedInstance = null
        if (savedInstanceState == null) {

            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                    new WorkoutsFragment()).commit();
            navigationView.setCheckedItem(R.id.viewWorkout);
        }

    }

    //when an item selected in drawer, change fragments
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) { //pass menu item selected
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        switch (menuItem.getItemId()){
            case R.id.viewWorkout: //view workout tapped
                //replace current frame layout in main, with new fragment layout
                fragmentTransaction.replace(R.id.fragment_container,
                    new WorkoutsFragment());
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
                break;

            case R.id.newWorkout:
                fragmentTransaction.replace(R.id.fragment_container,
                        new NewWorkoutsFragment());
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
                break;

            case R.id.benchmarks:
                break;

            case R.id.setReminders:
                fragmentTransaction.replace(R.id.fragment_container,
                        new SetRemindersFragment());
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
                break;

        }

        drawer.closeDrawer(GravityCompat.START); //close drawer
        return true; //item has been clicked
    }

    public void onBackPressed(){ //make sure back button doesn't close drawer
        if (drawer.isDrawerOpen(GravityCompat.START)){
            drawer.closeDrawer(GravityCompat.START);
        } else{
            super.onBackPressed(); //close activity as usual
        }
    }
}
